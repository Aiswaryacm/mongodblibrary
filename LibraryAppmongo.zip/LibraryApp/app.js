const express = require('express');
const app= express(); 
const nav = [
    {link:'/library',name:'Home'},
    {link:'/books',name:'Books'},
    {link:'/authors',name:'Authors'},
    {link:'/admin',name:'Add Book'},
    {link:'/adminauthor',name:'Add Author'}
];
const log = [
    {link:'/login',name:'login'},
    {link:'/signup',name:'Signup'},
    
];

app.use(express.urlencoded({extended:true})); 
app.use(express.static('./public'));


const booksRouter= require ('./src/routes/booksRouter')(nav,log)
const authorsRouter=require('./src/routes/authorsrouter')(nav,log)
const loginRouter=require('./src/routes/loginrouter')(nav,log)
const signupRouter=require('./src/routes/signuprouter')(nav,log)
const indexRouter=require('./src/routes/index')(nav,log)
const adminRouter= require ('./src/routes/adminRouter')(nav,log)
const adminauthorRouter= require ('./src/routes/adminauthorRouter')(nav,log)
const adminsignupRouter= require ('./src/routes/adminsignupRouter')(nav,log)
const libraryRouter= express.Router();




app.set('view engine','ejs');
app.set('views', __dirname+'/src/views');
app.use('/books',booksRouter);
app.use('/authors',authorsRouter);
app.use('/login',loginRouter);
app.use('/signup',signupRouter);
app.use('/library',libraryRouter);
app.use('/index',indexRouter);
app.use('/admin',adminRouter);
app.use('/adminauthor',adminauthorRouter);
app.use('/adminsignup',adminsignupRouter);



app.get('/', function(req,res){
    res.render('library',
    {
        nav:[{link:'/library',name:'Home'},{link:'/books',name:'Book'},{link:'/authors',name:'Authors'}],
       log:[{link:'/login',name:'LOGIN'},{link:'/signup',name:'SignUP'}]

    });
});
libraryRouter.get('/', function(req,res){
    res.render('index',
    {
       nav,
       log:[{link:'/login',name:'LOGIN'},{link:'/signup',name:'SignUP'}]

    });
});







// loginRouter.get('/login', function(req,res){
//     res.render('login',
//     {
//        nav:[{link:'/books',name:'Books'},{link:'/authors',name:'Authors'}],
//        log:[{link:'/login',name:'LOGIN'},{link:'/signup',name:'SignUP'}],
       
//     });
// });




app.listen(5000);