const express = require('express');
const adminsignupRouter = express.Router();
const signupdata = require('../model/Signupdata');


function router(nav){
    adminsignupRouter.get('/',function(req,res){
        res.render('signup',{
            nav
            
            
        });
    });

    
    adminsignupRouter.post('/signup',function(req,res){
        var item = {

            FirstName: String,
            LastName:String,
            PhoneNumber:String,
            email:String,
            Address:String,
            createpassword:String,
            confirmpassword:String,
            image:String

        }

       var signup =  signupdata(item);
        signup.save();
        res.redirect('/login');
        
    });

    return adminsignupRouter;
}


module.exports = router;
