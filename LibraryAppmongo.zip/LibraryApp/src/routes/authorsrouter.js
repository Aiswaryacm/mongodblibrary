const express = require('express');
const authorsRouter= express.Router();
const authordata = require('../model/Authordata');
function router(nav,log){
// var authors =[
//     {
//         name:'J. K. Rowling',
//         dob:'31 July 1965',
//         about:'J. K. Rowling, is a British author, screenwriter, producer, and philanthropist. She is best known for writing the Harry Potter fantasy series, which has won multiple awards and sold more than 500 million copies',
//         img:'author1.jpg'
//     },
//     {
//         name:'Chetan Bhagat',
//         dob:'22 April 1974',
//         about:'Chetan Bhagat has written eight novels and three non-fiction books. Right from the time his first best-selling novel Five Point Someone was published in 2004, his subsequent novels have found a place on bestsellers lists.',
//         img:'author2.jpg'
//     },
//     {
//         name:'Vaikom Muhammad Basheer',
//         dob:'21 January 1908 ',
//         about:'Vaikom Muhammad Basheer (21 January 1908 – 5 July 1994), fondly known as Beypore Sultan, was an Indian independence activist and writer of Malayalam literature . He was a writer, humanist, freedom fighter, novelist and short story writer',
//         img:'author3.jpg'
//     }

// ]

authorsRouter.get('/', function(req,res){
    authordata.find()
        .then(function(authors){
            
            res.render('authors',
            {
                nav,
               log,
               authors
            });


        })
        
    });
authorsRouter.get('/:id', function(req,res){
    const id=req.params.id
    authordata.findOne({_id:id})
    .then(function(author){
        res.render('author',
        {
            nav,
           log,
           author
        });
    })
    
});
authorsRouter.get('/delete/:id', function(req,res){
    const id=req.params.id
    authordata.findByIdAndDelete({_id:id})
    .then(function(author){
        res.redirect('/authors');
    
    });
    
});


return authorsRouter;
}
module.exports=router;