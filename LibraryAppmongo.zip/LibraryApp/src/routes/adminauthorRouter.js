const express = require('express');
const adminauthorRouter = express.Router();
const authordata = require('../model/Authordata');


function router(nav){
    adminauthorRouter.get('/',function(req,res){
        res.render('addauthor',{
            nav
            
            
        });
    });

    
    adminauthorRouter.post('/add',function(req,res){
        var item = {

        name: req.body.name,
        dob: req.body.dob,
        about: req.body.about,
        image: req.body.image

        }

       var author =  authordata(item);
        author.save();
        res.redirect('/authors');
        
    });

    return adminauthorRouter;
}


module.exports = router;
