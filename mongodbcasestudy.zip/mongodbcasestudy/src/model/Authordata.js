const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/library');

const Schema = mongoose.Schema;

const AuthorSchema = new Schema({
    name: String,
    dob:String,
    
    about:String,
    image:String
}); 

var authordata = mongoose.model('Authordata',AuthorSchema);

module.exports = authordata;
