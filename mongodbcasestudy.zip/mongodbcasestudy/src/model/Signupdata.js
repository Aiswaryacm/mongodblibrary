const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/library');

const Schema = mongoose.Schema;

const SignupSchema = new Schema({
    FirstName: String,
    LastName:String,
    PhoneNumber:String,
    email:String,
    Address:String,
    createpassword:String,
    confirmpassword:String,
    image:String
}); 

var signupdata = mongoose.model('Signupdata',SignupSchema);

module.exports = signupdata;