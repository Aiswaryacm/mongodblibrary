const express = require('express');
const indexRouter= express.Router();
function router(nav,log){
indexRouter.get('/', function(req,res){
    res.render('index',
    {
        nav,
       log
         
    });
}); 
return indexRouter;
}

module.exports=router;