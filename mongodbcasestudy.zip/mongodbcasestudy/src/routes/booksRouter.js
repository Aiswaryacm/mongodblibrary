const express = require('express');
const booksRouter= express.Router();
const bookdata = require('../model/Bookdata');
function router(nav,log){
    // var books =[
    //     {
    //         title:'The God Of Small things',
    //         author:'Arundati R',
    //         genre:'novel',
    //         img:'book1.jpg'
    //     },
    //     {
    //         title:'The White Tiger',
    //         author:'Aravind adiga',
    //         genre:'novel',
    //         img:'book2.jpg'
    //     },
    //     {
    //         title:'Manju',
    //         author:'M. T. Vasudevan Nair',
    //         genre:'novel',
    //         img:'book3.jpg'
    //     }
    
    // ]
    booksRouter.get('/', function(req,res){
        bookdata.find()
        .then(function(books){
            res.render('books',
            {
                nav,
               log,
               books
            });


        });
        
    });
    booksRouter.get('/:id', function(req,res){
        const id=req.params.id
        bookdata.findOne({_id:id})
        .then(function(book){
            res.render('book',
            {
                nav,
               log,
               book
            });
        })
        
    });
  
    booksRouter.get('/delete/:id', function(req,res){
        
        const id=req.params.id
        bookdata.findByIdAndDelete({_id:id})
        .then(function(book){
            res.redirect('/books');
        
        });
        
    });

    booksRouter.get('/edit/:id', function(req,res){
        
        const id=req.params.id
        bookdata.findOne({_id:id})
        .then(function(book){
            
            res.render('update',
            {
                nav,
               log,
               book
            });
        })
        
    });
    booksRouter.get('/update', function(req,res){
        
        const id=req.params.id
        bookdata.findByIdAndUpdate({_id:id})
        .then(function(book){
            
            res.render('update',
            {
                nav,
               log,
               book
            });
        })
        
    });
    








    return booksRouter;
}



 module.exports=router;